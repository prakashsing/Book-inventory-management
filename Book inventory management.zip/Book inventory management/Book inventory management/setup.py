from setuptools import setup

setup(
    name='Book inventory management',
    version='',
    packages=['book', 'book.migrations', 'bookstore'],
    url='',
    license='',
    author='Prakash',
    author_email='',
    description=''
)
